# Assignment 7.1.py
# Dev: Kenneth Clark
# Pickle it
# Demonstrates pickling and shelving data
# Original code from "Python Programming for the Absolute Beginner"
# 08-25-19

import pickle, shelve

item = []

# Requests user input to be stored to file
while True:
    usrInput = input("Please enter your item: ")
    if usrInput.lower() == "exit":
        break
    else:
        item.append(usrInput)
        print(item)

# saves user input in pickeled format
print("Saving item lists.")
items = [item[:]]
f = open("homeItems.dat", "wb")
pickle.dump(items, f)
f.close()

# retrives users list from saved file and changes it to readable list and prints it.
print("\nPrinting item lists")
f = open("homeItems.dat", "rb")
items = pickle.load(f)
print(items)
f.close()


input("\n\nPress the enter key to exit.")