# Assignment 07
# Dev: Kenneth Clark
# 08-25-19
# Introduction to Python

######################################
# Create a simple example of how you would use Python Exception Handling.
# Make sure to comment your code.
# Create a simple example of how you would use Python Pickling.
# Make sure to comment your code.
######################################

# Home inventory
# Pseudocode
# read text file
# Show user menu
# Get user input
# execute user choice
# save update file
# close file

# Menu

import pickle, shelve


def menu():
    """Print users options to screen"""
    print("""\t\t*******Menu**********
          1. Current list
          2. Add item to list
          3. Save item to list
          4. exit
          """)


def currentList():
    """User selects option 1 this opens txt file reads file and prints to screen"""
    objFile = open("homeInv1.txt", "r") # file does not exist in the correct folder in
    i = objFile.read()
    print("Current list consists of:" + "\n", i)


def addItem():
    """User selections option 2 this opens file and writes users input to file"""
    objFile = open("homeInv1.txt", "w")

    while True:

        usrInput = input(str("Please add your inventory item: "))
        if usrInput.lower() == "exit":
            break
        else:
            objFile.write(usrInput + "\n")

    objFile.close()

# I/O Main
def main():
    '''I/O Code for user entry and also contains the python exception code to capture if the text file
    does not exist.'''
    try:
        while True:
            menu()

            j = input("Please select a number from the menu: ")
            if j.lower() == "exit":
                break
            elif j == "1":
                currentList()
            elif j == "2":
                addItem()
    except FileNotFoundError as e:
        print("Error", str(e) + "\nPlease verify file name and location.")
    except Exception as e:
        print("It appears you have an error" + str(e))


# Starts program
main()

print("Thank you...Good bye.")
