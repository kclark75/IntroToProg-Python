# Assignment05
# ToDoList
# Dev: Kenneth Clark
# Introduction to Python

'''
Create a new script that managers a Todo_list. List will contain
different columns of data(Task, Priority) which will be stored in a python
dictionary.
1. Create a text file called Todo_list.txt using the following data:
    Clean House,low Pay Bills,high
2. When the program starts, load each row of data from the
    ToDo_list.txt text file into a Python dictionary.
    (The data will be stored like a row in a table.)
3. After you get the data in a Python dictionary,
    Add the new dictionary “row” into a Python list object
    (now the data will be managed as a table).
4. Display the contents of the List to the user.

5. Allow the user to Add or Remove tasks from the list using numbered choices.
    Something like this would work:
6. Save the data from the table into the Todo_list.txt file when the program exits.
'''

from typing import Tuple

# Variables
strChoice = None
strTask = ""
strPriority = ""
tplTasks: Tuple[str, str] = (strTask, strPriority)
tplTasks = ()
dicRow = {}

# Functions
def usrInp():
    input("Please hit enter to continue.")

# Introduction and instructions
print('\n\nWelcome to MacHome-Todo List')
print('#'*55)
print('This program will help you priority your ToDo list ')
print('#'*55)

# Load data from file
objFile = open("ToDo.txt", "a")
dicRow = {}
with open("/Users/kenclark/Documents/_PythonClass/Assignment05/Todo.txt") as f:
    for line in f:
        (key, val) = line.split()
        dicRow[str(key)] = val

# User prompt for item and estimated cost
while strChoice != 5:

    print("""
       Menu of Options
       1) Show current data
       2) Add a new item.
       3) Remove an existing item.
       4) Save Data to File
       5) Exit Program
       """)

    strChoice = input("Please select a menu option 1 thru 5: ")
    print()

    # 1) Show current data
    if strChoice == "1":
        print(dicRow, "\n")

    # 2) Add new item
    elif strChoice == "2":
        strTask = str(input("Please enter your task:\n"))
        strPriority = str(input("Please enter priority:\n"))
        tplTasks = (strTask, strPriority)
        dicRow.update({strTask:strPriority})
        print("Updated task list", dicRow)

    # 3) Remove existing item
    elif strChoice == "3":
        strTask = str(input("Please enter your task you wish to delete:\n"))
        tplTasks += strTask, strPriority
        del dicRow[strTask]
        print(dicRow)

    # 4) Save Data to File
    elif strChoice == "4":
        objFile.write("\n" + str(tplTasks))
        print("Your Todo list has been saved.")

    # Exit sequence
    elif strChoice == "5":
        break

objFile.close()
print("Thank you have a good day")